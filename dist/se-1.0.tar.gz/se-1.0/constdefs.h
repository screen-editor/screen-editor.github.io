/*
** constdefs.h
**
** Standard macro definitions for se screen editor
*/

#define	EOS '\0'
#define	ERR (-3)
#define	OK (-2)
#define	NO 0
#define	YES 1
