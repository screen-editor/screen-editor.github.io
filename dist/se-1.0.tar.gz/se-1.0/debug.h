/*
** debug.h
**
** put debugging code into programs
*/

#ifdef DEBUG
#define debug(x)	x
#else
#define debug(x)
#endif
