/*
 * $Header: constdefs.h,v 1.1 86/05/06 13:35:37 osadr Exp $
 */

/*
 * $Log:	constdefs.h,v $
 * Revision 1.1  86/05/06  13:35:37  osadr
 * Initial revision
 * 
 * 
 */

/*
** constdefs.h
**
** Standard macro definitions for se screen editor
*/

#define	EOS '\0'
#define	ERR (-3)
#define	OK (-2)
#define	NO 0
#define	YES 1
